"""Hardware and simulation adapters."""
