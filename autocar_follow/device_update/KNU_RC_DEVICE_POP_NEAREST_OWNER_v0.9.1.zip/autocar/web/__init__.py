"""Authenticated Flask dashboard."""
